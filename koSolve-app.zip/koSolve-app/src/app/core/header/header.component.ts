import { Component} from '@angular/core';
import { AuthService } from 'src/app/auth/auth.service';
import { DataStorageService } from 'src/app/shared/data-storage.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent{
  
  constructor(private authService: AuthService,
              private dataStorageService: DataStorageService) { }

  onLogout(){
    this.authService.logOut();
  }

  isAuthenticated(){
    return this.authService.isAuthenticated();

  }

  onSave(){
    this.dataStorageService.storePosts().subscribe((response)=>{
      console.log(response)
    }, (err)=>{
      console.log(err);
    });
  }

  onFetch(){
    this.dataStorageService.getPosts();
  }
}
