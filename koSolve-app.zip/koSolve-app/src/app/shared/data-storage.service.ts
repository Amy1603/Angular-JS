import { AuthService } from '../auth/auth.service';
import { Http,Response } from '@angular/http';
import { PostsService } from '../posts/posts.service';
import {map} from 'rxjs/operators';
import { User } from './user.model';
import { Injectable } from '@angular/core';

@Injectable()
export class DataStorageService{

    constructor(private authService: AuthService,
                private http: Http,
                private postService: PostsService){}

    storePosts(){
        const token = this.authService.getToken();
        console.log("Posts : "+this.postService.getPosts());
        return this.http.put('https://kosolve-project-app.firebaseio.com/users.json?auth='+token,
        this.postService.getPosts());
    }

    getPosts(){
        const token = this.authService.getToken();
        this.http.get('https://kosolve-project-app.firebaseio.com/users.json?auth='+token)
        .pipe(map(
            (response:Response)=>{
                const user: User[]=response.json();
                // for(let post of user){
                //     if(!post['post']){
                //         post['post']={};
                //     }
                // }
                return user;
            }
        )).subscribe(
            (userPost: User[])=>{
                this.postService.setPosts(userPost);
            });
    }
}