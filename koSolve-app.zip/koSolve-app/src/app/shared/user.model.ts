import { Post } from './post.model';

export class User{
    constructor(public name:string,public post: Post[]){}
}