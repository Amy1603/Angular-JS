import { Component, OnInit } from '@angular/core';
import * as firebase from 'firebase';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'koSolve-app';

  ngOnInit(){
    firebase.initializeApp({
      apiKey: "AIzaSyBbEB9ZCji09O1-CkNbUBDaZzPHM0_0l7o",
      authDomain: "kosolve-project-app.firebaseapp.com"
    });
  }
}
