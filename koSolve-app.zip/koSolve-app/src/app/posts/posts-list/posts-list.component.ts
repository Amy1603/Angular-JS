import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { PostsService } from '../posts.service';
import { User } from 'src/app/shared/user.model';

@Component({
  selector: 'app-posts-list',
  templateUrl: './posts-list.component.html',
  styleUrls: ['./posts-list.component.css']
})
export class PostsListComponent implements OnInit,OnDestroy {
  userPost: User[];
  subscription: Subscription;

  constructor(private postService: PostsService) { }

  ngOnInit() {
    this.subscription = this.postService.postsChanged.subscribe(
      (userPost: User[])=>{
        this.userPost=userPost;
      }
    );
    this.userPost = this.postService.getPosts();
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

}
