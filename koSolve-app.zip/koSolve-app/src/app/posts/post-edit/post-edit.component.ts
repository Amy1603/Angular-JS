import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray} from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { PostsService } from '../posts.service';

@Component({
  selector: 'app-post-edit',
  templateUrl: './post-edit.component.html',
  styleUrls: ['./post-edit.component.css']
})
export class PostEditComponent implements OnInit {
  id:number;
  editMode=false;
  postForm: FormGroup;
  

  constructor(private route: ActivatedRoute,
    private router: Router,
    private postsService: PostsService) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params: Params)=>{
        this.id = +params['id'];
        this.editMode = params['id'] != null;
        this.initForm();
      }
    )
  }

  private initForm(){
    
    let userName='';
    let post = new FormArray([]);
    post.push(
      new FormGroup({
        'title': new FormControl(null,Validators.required),
        'description': new FormControl(null,Validators.required)
      }));

    if(this.editMode){
      // userName= 'AMY';
      console.log(this.id);
        const userPost= this.postsService.getPost(this.id);
        console.log(userPost);
        userName=userPost.name;
        
        post=new FormArray([]);
        if(userPost['post']){
          for(let p of userPost.post){
            post.push(
              new FormGroup({
                'title': new FormControl(p.title,Validators.required),
                'description': new FormControl(p.description,Validators.required)
              })
            )
          }
        }
    }
    
    this.postForm = new FormGroup({
      'name': new FormControl(userName,Validators.required),
      'post': post
    });
  }

  OnAdd(){
    (<FormArray>this.postForm.get('post')).push(
      new FormGroup({
        'title': new FormControl(null,Validators.required),
        'description': new FormControl(null,Validators.required)
      })
    );
    }
      
    onSubmit(){
      if(this.editMode){
        this.postsService.updatePost(this.id,this.postForm.value);
      }else{
        this.postsService.addPost(this.postForm.value);
      }
      this.onCancel();
    }

    onCancel(){
      this.router.navigate(['../'],{relativeTo: this.route});
    }

    onDelete(index:number){
      (<FormArray>this.postForm.get('post')).removeAt(index);
    }

    getControls(){
      return (<FormArray>this.postForm.get('post')).controls;
    }
}
