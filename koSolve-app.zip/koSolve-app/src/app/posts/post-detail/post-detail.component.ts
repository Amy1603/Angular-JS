import { Component, OnInit } from '@angular/core';
import {Params, Router, ActivatedRoute } from '@angular/router';
import { User } from 'src/app/shared/user.model';
import { PostsService } from '../posts.service';

@Component({
  selector: 'app-post-detail',
  templateUrl: './post-detail.component.html',
  styleUrls: ['./post-detail.component.css']
})
export class PostDetailComponent implements OnInit {
  user: User
  id: number;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private postsService: PostsService) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params:Params)=>{
        this.id = +params['id'];
        this.user=this.postsService.getPost(this.id);
      }
    )
  }

  onDelete(){
    this.postsService.deletePost(this.id);
    this.router.navigate(['/post']);
  }
}
