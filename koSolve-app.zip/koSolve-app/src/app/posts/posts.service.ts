import { User } from '../shared/user.model';
import { Post } from '../shared/post.model';
import { Subject } from 'rxjs';

export class PostsService{
    postsChanged=new Subject<User[]>();

    private userPost: User[]=[
        new User('Jay',
            [new Post('Narendra Modi','He becomes the PM again!!')]
        ),
        new User('Jack',
            [new Post('Spiti','Rocking Adventure')]
        ),
        new User('Swati',
            [new Post('Bitcoin','A Sad story!!!!!!!!!!')]
        ),
        new User('Amy',
            [new Post('Ladakh','Heaven on earth...Must have on bucket list!')]
        ),
        new User('Manu',
            [new Post('AIR Force','SSB is really tough....')]
        )
    ];

    setPosts(userPost: User[]){
        this.userPost = userPost;
        this.postsChanged.next(this.userPost.slice());
    }

    getPosts(){
        return this.userPost.slice();
    }

    getPost(index:number){
        console.log("ind: ",index);
        return this.userPost[index];
    }

    addPost(user: User){
        this.userPost.push(user);
        this.postsChanged.next(this.userPost.slice());
    }

    updatePost(index:number,newPost:User){
        this.userPost[index]=newPost
        this.postsChanged.next(this.userPost.slice());
    }

    deletePost(index:number){
        this.userPost.splice(index,1);
        this.postsChanged.next(this.userPost.slice());
    }
}
