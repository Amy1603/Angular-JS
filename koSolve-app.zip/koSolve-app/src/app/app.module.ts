import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SigninComponent } from './auth/signin/signin.component';
import { SignupComponent } from './auth/signup/signup.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PostsComponent } from './posts/posts.component';
import { PostDetailComponent } from './posts/post-detail/post-detail.component';
import { PostEditComponent } from './posts/post-edit/post-edit.component';
import { PostsListComponent } from './posts/posts-list/posts-list.component';
import { HeaderComponent } from './core/header/header.component';
import { HomeComponent } from './core/home/home.component';
import { AuthService } from './auth/auth.service';
import { HttpModule } from '@angular/http';
import { PostsService } from './posts/posts.service';
import { DataStorageService } from './shared/data-storage.service';
import { AppRoutingModule } from './app-routing.module';
import { PostItemComponent } from './posts/posts-list/post-item/post-item.component';
import { AuthGuardService } from './auth/auth-guard.service';

@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    SignupComponent,
    PostsComponent,
    PostDetailComponent,
    PostEditComponent,
    PostsListComponent,
    HeaderComponent,
    HomeComponent,
    PostItemComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [AuthService,PostsService,DataStorageService,AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
