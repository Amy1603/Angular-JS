import {Routes, RouterModule} from '@angular/router';
import { SignupComponent } from './auth/signup/signup.component';
import { NgModule } from '@angular/core';
import { SigninComponent } from './auth/signin/signin.component';
import { HomeComponent } from './core/home/home.component';
import { PostsComponent } from './posts/posts.component';
import { PostEditComponent } from './posts/post-edit/post-edit.component';
import { PostDetailComponent } from './posts/post-detail/post-detail.component';
import { AuthGuardService } from './auth/auth-guard.service';

const appRoute: Routes=[
    {path:'', component:HomeComponent},
    {path:'signin',component:SigninComponent},
    {path:'signup',component:SignupComponent},
    {path:'post',component:PostsComponent,children:[
        {path:'new',component:PostEditComponent},
        {path:':id',component:PostDetailComponent},
        {path:':id/edit',component:PostEditComponent}
    ], canActivate:[AuthGuardService]}
];

@NgModule({
    imports:[
        RouterModule.forRoot(appRoute)
    ],
    exports:[RouterModule]
})

export class AppRoutingModule{}