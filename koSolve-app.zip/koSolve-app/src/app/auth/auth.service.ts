import { Router } from '@angular/router';
import * as firebase from 'firebase';
import { Injectable } from '@angular/core';

@Injectable()
export class AuthService{
    token: string;

    constructor(private router: Router){}

    signUpUser(email:string,password:string){
        firebase.auth().createUserWithEmailAndPassword(email,password).then(
            response=>{
                this.router.navigate(['/post']);
                firebase.auth().currentUser.getIdToken().then(
                    (token:string)=>{
                        this.token = token;
                    }
                )
            }
        ).catch( error=>{alert(error);}
        );
    }

    signInUser(email:string,password:string){
        firebase.auth().signInWithEmailAndPassword(email,password).then(
            response=>{
                this.router.navigate(['/post']);
                firebase.auth().currentUser.getIdToken().then(
                    (token:string)=>{
                        this.token = token;
                    }
                )
            }
        ).catch(err=>alert(err))
    }

    logOut(){
        firebase.auth().signOut();
        this.token=null;
        this.router.navigate(['']);
    }

    getToken(){
        firebase.auth().currentUser.getIdToken().then(
            (token:string)=>{
                this.token = token;
            }
        );
        return this.token;
    }

    isAuthenticated(){
        return this.token!=null;
    }

    forgot(email:string){
        firebase.auth().sendPasswordResetEmail(email).then(
            response=>{
                alert('Password reset link has been sent to your email id.');
                console.log(response);
            }
        ).catch(err=>{
           alert(err)
        });

        
    }
}